import os
import time
from pathlib import Path
from functools import wraps
from datetime import datetime
from dotenv import load_dotenv
from flask import Flask, render_template, request, redirect, url_for, flash, session, send_from_directory, current_app
from flask_mysqldb import MySQL
from flask_mail import Mail, Message
from itsdangerous import URLSafeTimedSerializer, SignatureExpired
from werkzeug.utils import secure_filename

# Load environment
load_dotenv()
app = Flask(__name__)
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY','change_this_secret')

# MySQL config from env
app.config['MYSQL_HOST'] = os.getenv('MYSQL_HOST','127.0.0.1')
app.config['MYSQL_USER'] = os.getenv('MYSQL_USER','root')
app.config['MYSQL_PASSWORD'] = os.getenv('MYSQL_PASSWORD','')
app.config['MYSQL_DB'] = os.getenv('MYSQL_DB','rt3dprint')

# Upload folders
BASE_DIR = Path(__file__).parent
UPLOAD_DIR = BASE_DIR / 'static' / 'uploads'
PAYMENT_DIR = UPLOAD_DIR / 'payment_screenshots'
FINAL_DIR = UPLOAD_DIR / 'final_files'
for d in (UPLOAD_DIR, PAYMENT_DIR, FINAL_DIR):
    d.mkdir(parents=True, exist_ok=True)

app.config['MAX_CONTENT_LENGTH'] = 80 * 1024 * 1024

# Mail config
app.config['MAIL_SERVER'] = os.getenv('MAIL_SERVER','smtp.gmail.com')
app.config['MAIL_PORT'] = int(os.getenv('MAIL_PORT', 587))
app.config['MAIL_USE_TLS'] = os.getenv('MAIL_USE_TLS', 'True') in ('True','true','1')
app.config['MAIL_USERNAME'] = os.getenv('MAIL_USERNAME')
app.config['MAIL_PASSWORD'] = os.getenv('MAIL_PASSWORD')
app.config['MAIL_DEFAULT_SENDER'] = app.config['MAIL_USERNAME']

mysql = MySQL(app)
mail = Mail(app)
s = URLSafeTimedSerializer(app.config['SECRET_KEY'])
ADMIN_EMAIL = os.getenv('ADMIN_EMAIL', app.config['MAIL_USERNAME'])

# Helpers for DB queries
def query_db(query, args=(), fetchone=False, commit=False):
    cur = mysql.connection.cursor()
    cur.execute(query, args)
    if commit:
        mysql.connection.commit()
    rows = cur.fetchall()
    cur.close()
    if fetchone:
        return rows[0] if rows else None
    return rows

# context processor
@app.context_processor
def inject_now():
    return {'current_year': lambda: datetime.utcnow().year}

# Auth decorators
def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            flash("Please log in.", "warning")
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated

def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if session.get('role') != 'admin':
            flash("Admin access required.", "danger")
            return redirect(url_for('index'))
        return f(*args, **kwargs)
    return decorated

def send_email(to, subject, body, html=None, reply_to=None):
    try:
        msg = Message(subject, recipients=[to])
        msg.body = body
        if html:
            msg.html = html
        if reply_to:
            msg.reply_to = reply_to
        mail.send(msg)
        return True, None
    except Exception as e:
        current_app.logger.exception("Mail error")
        return False, str(e)

# Routes
@app.route('/')
def index():
    user = None
    if 'user_id' in session:
        # minimal user fetch
        cur = mysql.connection.cursor()
        cur.execute("SELECT id, name, username, email FROM users WHERE id=%s", (session['user_id'],))
        row = cur.fetchone()
        cur.close()
        if row:
            user = {'id':row[0],'name':row[1],'username':row[2],'email':row[3]}
    recent_rows = query_db("SELECT id, project_name, project_type, status, created_at FROM requests ORDER BY created_at DESC LIMIT 6")
    recent = [dict(id=r[0], project_name=r[1], project_type=r[2], status=r[3], created_at=r[4]) for r in recent_rows]
    return render_template('home.html', user=user, recent=recent)

@app.route('/signup', methods=['GET','POST'])
def signup():
    if request.method=='POST':
        name = request.form.get('name','').strip()
        username = request.form.get('username','').strip()
        email = request.form.get('email','').strip()
        password = request.form.get('password','').strip()
        if not (username and email and password):
            flash("Please fill required fields.", "danger")
            return redirect(url_for('signup'))
        # check existing
        r = query_db("SELECT id FROM users WHERE username=%s OR email=%s", (username, email))
        if r:
            flash("Username or email already exists.", "danger")
            return redirect(url_for('signup'))
        cur = mysql.connection.cursor()
        cur.execute("INSERT INTO users (name, username, email, password, role, verified) VALUES (%s,%s,%s,%s,%s,%s)",
                    (name, username, email, password, 'user', 0))
        mysql.connection.commit()
        cur.close()
        token = s.dumps(email, salt='email-confirm')
        confirm_url = url_for('confirm_email', token=token, _external=True)
        subject = "Confirm your RT3DPRINT account"
        body = f"Hi {name or username},\n\nPlease confirm your email: {confirm_url}"
        ok, err = send_email(email, subject, body)
        if ok:
            flash("Signup successful. Check your email for confirmation link.", "success")
        else:
            flash(f"Signup saved but failed to send email: {err}", "warning")
        return redirect(url_for('login'))
    return render_template('signup.html')

@app.route('/confirm/<token>')
def confirm_email(token):
    try:
        email = s.loads(token, salt='email-confirm', max_age=60*60*24)
    except SignatureExpired:
        flash("Link expired. Sign up again.", "danger")
        return redirect(url_for('signup'))
    cur = mysql.connection.cursor()
    cur.execute("UPDATE users SET verified=1 WHERE email=%s", (email,))
    mysql.connection.commit()
    cur.close()
    flash("Email confirmed. You can log in.", "success")
    return redirect(url_for('login'))

@app.route('/login', methods=['GET','POST'])
def login():
    if request.method=='POST':
        username = request.form.get('username','').strip()
        password = request.form.get('password','').strip()
        role = request.form.get('role','user')
        row = query_db("SELECT id, name, username, email, password, role, verified FROM users WHERE username=%s", (username,), fetchone=True)
        if not row:
            flash("Invalid credentials.", "danger")
            return redirect(url_for('login'))
        uid, name, uname, email, passwd, urole, verified = row
        if passwd != password or urole != role:
            flash("Invalid credentials or wrong role.", "danger")
            return redirect(url_for('login'))
        if not verified:
            flash("Please confirm your email before logging in.", "warning")
            return redirect(url_for('login'))
        session['user_id'] = uid
        session['username'] = uname
        session['name'] = name
        session['role'] = urole
        flash("Logged in.", "success")
        if urole == 'admin':
            return redirect(url_for('admin_dashboard'))
        return redirect(url_for('user_dashboard'))
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    flash("Logged out.", "info")
    return redirect(url_for('index'))

@app.route('/dashboard')
@login_required
def user_dashboard():
    uid = session['user_id']
    rows = query_db("SELECT * FROM requests WHERE user_id=%s ORDER BY created_at DESC", (uid,))
    keys = ['id','user_id','project_name','project_type','description','deadline','created_at','status','payment_amount','payment_details','payment_screenshot','final_file','final_filename']
    reqs = [dict(zip(keys, r)) for r in rows]
    return render_template('user_dashboard.html', requests=reqs)

@app.route('/request/new', methods=['GET','POST'])
@login_required
def new_request():
    if request.method=='POST':
        uid = session['user_id']
        project_name = request.form.get('project_name','').strip()
        project_type = request.form.get('project_type')
        description = request.form.get('description','').strip()
        deadline = request.form.get('deadline') or None
        req_id = int(time.time()*1000)
        cur = mysql.connection.cursor()
        cur.execute("INSERT INTO requests (id, user_id, project_name, project_type, description, deadline, status) VALUES (%s,%s,%s,%s,%s,%s,%s)",
                    (req_id, uid, project_name, project_type, description, deadline, 'pending'))
        mysql.connection.commit()
        cur.close()
        # notify admin
        subject = f"New 3D Print Request: {project_name}"
        body = f"User {session.get('username')} submitted {project_name}."
        send_email(ADMIN_EMAIL, subject, body)
        flash("Request submitted.", "success")
        return redirect(url_for('user_dashboard'))
    return render_template('request_form.html')

@app.route('/request/<int:req_id>/upload_payment', methods=['POST'])
@login_required
def upload_payment(req_id):
    file = request.files.get('payment_screenshot')
    if not file:
        flash("No file selected.", "warning")
        return redirect(url_for('user_dashboard'))
    filename = secure_filename(f"{req_id}_{file.filename}")
    path = PAYMENT_DIR / filename
    file.save(path)
    cur = mysql.connection.cursor()
    cur.execute("UPDATE requests SET payment_screenshot=%s, status=%s WHERE id=%s", (filename, 'payment-uploaded', req_id))
    mysql.connection.commit()
    cur.close()
    send_email(ADMIN_EMAIL, f"Payment Proof Uploaded for {req_id}", "Login to admin to review.")
    flash("Uploaded. Admin notified.", "success")
    return redirect(url_for('user_dashboard'))

@app.route('/request/<int:req_id>/feedback', methods=['POST'])
@login_required
def submit_feedback(req_id):
    rating = int(request.form.get('rating',5))
    message = request.form.get('message','')
    uid = session['user_id']
    cur = mysql.connection.cursor()
    cur.execute("INSERT INTO feedback (user_id, request_id, rating, message) VALUES (%s,%s,%s,%s)", (uid, req_id, rating, message))
    mysql.connection.commit()
    cur.close()
    send_email(ADMIN_EMAIL, f"Feedback for {req_id}", f"Rating: {rating}\nMessage:{message}")
    flash("Feedback submitted.", "success")
    return redirect(url_for('user_dashboard'))

@app.route('/admin')
@admin_required
def admin_dashboard():
    rows = query_db("SELECT r.*, u.username, u.email FROM requests r JOIN users u ON r.user_id=u.id ORDER BY r.created_at DESC")
    keys = ['id','user_id','project_name','project_type','description','deadline','created_at','status','payment_amount','payment_details','payment_screenshot','final_file','final_filename','username','email']
    reqs = [dict(zip(keys, r)) for r in rows]
    return render_template('admin_dashboard.html', requests=reqs)

@app.route('/admin/<int:req_id>/set_payment', methods=['POST'])
@admin_required
def admin_set_payment(req_id):
    amount = request.form.get('amount')
    details = request.form.get('payment_details')
    cur = mysql.connection.cursor()
    cur.execute("UPDATE requests SET payment_amount=%s, payment_details=%s, status=%s WHERE id=%s", (amount, details, 'payment-requested', req_id))
    mysql.connection.commit()
    cur.close()
    row = query_db("SELECT u.email, u.name, u.username, r.project_name FROM requests r JOIN users u ON r.user_id=u.id WHERE r.id=%s", (req_id,), fetchone=True)
    if row:
        email, name, username, pname = row[0], row[1], row[2], row[3]
        send_email(email, f"Payment Requested for {pname}", f"Pay ₹{amount} to: {details}")
    flash("Payment details set.", "success")
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/<int:req_id>/update_status', methods=['POST'])
@admin_required
def admin_update_status(req_id):
    new_status = request.form.get('status')
    cur = mysql.connection.cursor()
    cur.execute("UPDATE requests SET status=%s WHERE id=%s", (new_status, req_id))
    mysql.connection.commit()
    cur.close()
    row = query_db("SELECT u.email, u.name, u.username, r.project_name FROM requests r JOIN users u ON r.user_id=u.id WHERE r.id=%s", (req_id,), fetchone=True)
    if row:
        send_email(row[0], f"Status Updated for {row[3]}", f"New status: {new_status}")
    flash("Status updated.", "success")
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/<int:req_id>/upload_final', methods=['POST'])
@admin_required
def admin_upload_final(req_id):
    file = request.files.get('final_file')
    if not file:
        flash("No file selected.", "warning")
        return redirect(url_for('admin_dashboard'))
    filename = secure_filename(f"{req_id}_{file.filename}")
    path = FINAL_DIR / filename
    file.save(path)
    cur = mysql.connection.cursor()
    cur.execute("UPDATE requests SET final_file=%s, final_filename=%s, status=%s WHERE id=%s", (filename, file.filename, 'completed', req_id))
    mysql.connection.commit()
    cur.close()
    row = query_db("SELECT u.email, u.name, u.username FROM requests r JOIN users u ON r.user_id=u.id WHERE r.id=%s", (req_id,), fetchone=True)
    if row:
        download_url = url_for('download_final', filename=filename, _external=True)
        send_email(row[0], "Your 3D Print is Ready", f"Download: {download_url}")
    flash("Final file uploaded.", "success")
    return redirect(url_for('admin_dashboard'))

@app.route('/uploads/final/<path:filename>')
@login_required
def download_final(filename):
    p = FINAL_DIR / filename
    if not p.exists():
        flash("File not found.", "danger")
        return redirect(url_for('user_dashboard'))
    return send_from_directory(FINAL_DIR, filename, as_attachment=True)

@app.route('/uploads/payment/<path:filename>')
@admin_required
def view_payment(filename):
    p = PAYMENT_DIR / filename
    if not p.exists():
        flash("File not found.", "danger")
        return redirect(url_for('admin_dashboard'))
    return send_from_directory(PAYMENT_DIR, filename)

def ensure_admin():
    row = query_db("SELECT id FROM users WHERE role='admin'")
    if not row:
        cur = mysql.connection.cursor()
        # admin credentials set by environment variables or default
        admin_email = os.getenv('ADMIN_EMAIL', app.config['MAIL_USERNAME'])
        admin_password = os.getenv('ADMIN_PASS', 'rThanush@0828')
        cur.execute("INSERT INTO users (name, username, email, password, role, verified) VALUES (%s,%s,%s,%s,%s,%s)",
                    ("Administrator","admin",admin_email,admin_password,"admin",1))
        mysql.connection.commit()
        cur.close()

ensure_admin()

if __name__ == '__main__':
    app.run(debug=True)
